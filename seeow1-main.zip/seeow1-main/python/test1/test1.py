import socket
s=socket.socket()
host=socket.gethostname()
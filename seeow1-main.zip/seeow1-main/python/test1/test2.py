w=0
for x in range (1,5):
    for y in range(1,5):
        for z in range (1,5):
            print(w)
            w=w+1
print(w)
#include <iostream>
#include <windows.h>
using namespace std;
int b(int);
int main()
{
	int a;
	a:
	//scanf_s("%d", &a);
	//cout << a;
	b(0);
	goto a;
	return 0;
}
int b(int i)
{
	int j[100000];
	cout << i<<" ";
	b(i+1);
	return 0;


}

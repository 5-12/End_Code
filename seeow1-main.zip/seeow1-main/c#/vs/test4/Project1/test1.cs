﻿
//using Box;
using Box;
using System;
namespace Boxs
{
    public class Box1
    {
        public class Val
        {
            public static int a;
            public static int[] b = new int[10000];
        }
    }
}
namespace Test1
{

    public static class Mains
    {
        
        public static void Main()
        {
            Boxs.Box1.Val.a = Console.Read()-48;
            for (int i = 0; i < Boxs.Box1.Val.a; i++)
            {
                Boxs.Box1.Val.b[i] = Console.Read();
                if (Boxs.Box1.Val.b[i] >= 48 && Boxs.Box1.Val.b[i]<=57)
                {
                    Boxs.Box1.Val.b[i] -= 48;
                }
            }
            for (int i = 0; i < Boxs.Box1.Val.a; i++)
            {
                if (Boxs.Box1.Val.b[i] >= 48 && Boxs.Box1.Val.b[i] <= 57)
                {
                    Console.WriteLine(Boxs.Box1.Val.b[i]);
                    Console.Write(" ");
                }
            }
            //Test1.Box1;
            //box1.a = Console.Read();
            Console.WriteLine(Boxs.Box1.Val.a);
        }
    }
}

﻿using System;

namespace tool
{
    public class Io
    {
        public class Box
        {
           public static int[] main = new int[100];
        }
        public static int Test1(int a)
        {
           
            for (int i = 0; i <=a+2;i++)
            {
                Box.main[i]=Console.Read();
                if (Box.main[i]==10)
                {
                    return i-1;
                }
                Box.main[i] -= 48;
             }
            return 0;
         }
    }
    /* public class Ascll
     {
         public static int Ascllc(int a)
         {
             return a -= 48;
         }
         public static int AscllAdd(int a)
         {
             return a += 48;
         }
     }

     public class Add
     {
         public static int A(int a, int b)
         {
             return a+b;
         }
     }
    */
}
namespace mains
{
    public class Mains
    {
        public static void Main()
        {
            int a,b,c=0;
            b=Console.Read()-48;
            a=tool.Io.Test1(10);
            for(int i=0;i<=a;i++)
            {
                if (tool.Io.Box.main[i]==32)
                {
                    i++;
                }
                c += tool.Io.Box.main[i];
            }
            Console.WriteLine(c);
            //tool.Io.Box.main[0];
            /*
             int a=0;
            //int b;
            int [] c=new int[100];
            a = Console.Read()-48;
            for(int i=0;i<=a;i++)
            {
                c[i]=Console.Read();
            }
            for(int i=0;i<=a;i++)
            {
                Console.WriteLine(c[i]);
            }*/
            //Console.WriteLine(a);
            //a = Console.Read() - 48;
        }
    }
}
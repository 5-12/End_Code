using System;
namespace test
{
   class test
   {
      static void Main()
      {
         int a;
         string b;
         Console.WriteLine("a");
         b=Console.Read();
         a=(int) Console.Read();
         Console.WriteLine((string) a,b);
      }
   }
}
#include <iostream>
using namespace std;
int n;
int main(int argc, char const *argv[])
{
    cin>>n;
    for (int i = 1; i <= n; i++)
    {
        cout<<"(2";  
    }
    cout<<"(0)";
    if (n%2==1)
    {
        cout<<"+2"<<endl;
    }
    
    return 0;
}

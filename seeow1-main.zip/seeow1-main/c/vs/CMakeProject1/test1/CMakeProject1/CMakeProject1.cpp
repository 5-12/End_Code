﻿// CMakeProject1.cpp: 定义应用程序的入口点。
//

#include "CMakeProject1.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}

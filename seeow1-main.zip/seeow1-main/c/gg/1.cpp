#include <bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
    char a;
    while(1)
    {
        a=getchar();
        cout<<(int)a<<endl;
    }
    return 0;
}

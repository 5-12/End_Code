#include <windows.h>
#include <windows.ui.h>
using namespace std;
int WINAPI WinMain(void)
{

}